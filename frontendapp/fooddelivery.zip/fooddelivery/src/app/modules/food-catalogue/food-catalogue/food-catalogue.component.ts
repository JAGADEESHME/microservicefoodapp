import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FoodCataloguePage } from '../../../Shared/models/FoodCataloguePage';
import { FoodItem } from '../../../Shared/models/FoodItem';
import { FooditemService } from '../service/fooditem.service';

@Component({
  selector: 'app-food-catalogue',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './food-catalogue.component.html',
  styleUrls: ['./food-catalogue.component.css'] // Corrected from styleUrl to styleUrls
})
export class FoodCatalogueComponent implements OnInit {

  restaurantId: number | null = null;
  foodItemResponse: FoodCataloguePage | undefined;
  foodItemCart: FoodItem[] = [];
  orderSummary: FoodCataloguePage | undefined;

  constructor(
    private route: ActivatedRoute,
    private foodItemService: FooditemService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      this.restaurantId = id ? +id : null;
      if (this.restaurantId !== null) {
        this.getFoodItemsByRestaurant(this.restaurantId);
      }
    });
  }

  getFoodItemsByRestaurant(restaurantId: number): void {
    this.foodItemService.getFoodItemsByRestaurant(restaurantId).subscribe(
      data => {
        this.foodItemResponse = data;
        console.log(this.foodItemResponse)
      }
    );
  }

  increment(food: FoodItem): void {
    food.quantity++;
    const index = this.foodItemCart.findIndex(item => item.id === food.id);
    if (index === -1) {
      // If record does not exist, add it to the array
      this.foodItemCart.push(food);
    } else {
      // If record exists, update it in the array
      this.foodItemCart[index] = food;
    }
  }

  decrement(food: FoodItem): void {
    if (food.quantity > 0) {
      food.quantity--;

      const index = this.foodItemCart.findIndex(item => item.id === food.id);
      if (this.foodItemCart[index].quantity === 0) {
        this.foodItemCart.splice(index, 1);
      } else {
        // If record exists, update it in the array
        this.foodItemCart[index] = food;
      }
    }
  }

  onCheckOut(): void {
    if (this.foodItemResponse && this.foodItemResponse.restaurant) {
      this.orderSummary = {
        foodItemsList: this.foodItemCart,
        restaurant: this.foodItemResponse.restaurant
      };
      this.router.navigate(['/orderSummary'], { queryParams: { data: JSON.stringify(this.orderSummary) } });
    } else {
      console.error('Restaurant data is not available.');
    }
  }
}
